// var Alexa = require('alexa-sdk');
// var constants = require('../constants/constants');

// // define onBoarding Handlers

// var mainStateHandlers = Alexa.CreateStateHandler(constants.states.MAIN, {
//     // the object that contains our handlers
// })

// module.exports = mainStateHandlers;