module.exports = [
    {
        lyric: 'I got I got I got I got Loyalty, got Royalty inside my DNA',
        correctAnswer: 'Kendrick Lamar',
        Answers: ['Kanye West', 'Tupac', 'Kendrick Lamar']
    },
    {
        lyric: 'The fog and the smog of news media that logs, false narratives of gods that came up against the odds',
        correctAnswer: 'A tribe called quest',
        Answers: ['A Tribe called quest', 'Arrested Development', 'NWA']
    },
    {
        lyric: 'The only thing that close quicker than our caskets be the factories',
        correctAnswer: 'Run the Jewels',
        Answers: ['Run the jewels', '50 Cent', 'Kanye West']
    }
];